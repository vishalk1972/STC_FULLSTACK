CREATE TABLE students (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR,
    last_name VARCHAR,
    email VARCHAR,
    mobile_number VARCHAR,
    roll_number INT,
    reg_number VARCHAR,
    password VARCHAR
);

CREATE TABLE student_token (
    id SERIAL PRIMARY KEY,
    token VARCHAR NOT NULL,
    fk_student INT NOT NULL,
    created_at TIMESTAMP,
    CONSTRAINT fk_student FOREIGN KEY (fk_student) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE teachers (
    id SERIAL PRIMARY KEY,
    name VARCHAR,
    email VARCHAR,
    mobile_number VARCHAR,
    reg_number VARCHAR,
    designation VARCHAR,
    password VARCHAR
);

CREATE TABLE teacher_token (
    id SERIAL PRIMARY KEY,
    token VARCHAR NOT NULL,
    fk_teacher INT NOT NULL,
    created_at TIMESTAMP,
    CONSTRAINT fk_teacher FOREIGN KEY (fk_teacher) REFERENCES teachers(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE admins (
    id SERIAL PRIMARY KEY,
    username VARCHAR,
    password VARCHAR
);

CREATE TABLE admin_token (
    id SERIAL PRIMARY KEY,
    token VARCHAR NOT NULL,
    fk_admin INT NOT NULL,
    created_at TIMESTAMP,
    CONSTRAINT fk_admin FOREIGN KEY (fk_admin) REFERENCES admins(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE domains (
    id SERIAL PRIMARY KEY,
    domain_name VARCHAR
);

CREATE TABLE domain_student (
    id SERIAL PRIMARY KEY,
    fk_domain INT,
    fk_student INT,
    CONSTRAINT fk_domain FOREIGN KEY (fk_domain) REFERENCES domains(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_student FOREIGN KEY (fk_student) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE domain_teacher (
    id SERIAL PRIMARY KEY,
    fk_domain INT,
    fk_teacher INT,
    CONSTRAINT fk_domain FOREIGN KEY (fk_domain) REFERENCES domains(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_teacher FOREIGN KEY (fk_teacher) REFERENCES teachers(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE groups (
    id SERIAL PRIMARY KEY,
    fk_teacher INT,
    fk_domain INT,
    group_name VARCHAR,
    CONSTRAINT fk_teacher FOREIGN KEY (fk_teacher) REFERENCES teachers(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_domain FOREIGN KEY (fk_domain) REFERENCES domains(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE student_group
(
    id SERIAL PRIMARY KEY,
    fk_student INT,
    fk_group INT,
    CONSTRAINT fk_student FOREIGN KEY (fk_student) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_group FOREIGN KEY (fk_group) REFERENCES groups(id) ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE TABLE datas (
    id SERIAL PRIMARY KEY,
    fk_group INT,
    teacher_uploaded BOOLEAN,
    fk_student INT,
    data TEXT,
    is_file BOOLEAN,
    uploaded_at TIMESTAMP,
    CONSTRAINT fk_group FOREIGN KEY (fk_group) REFERENCES groups(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_student FOREIGN KEY (fk_student) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE review_group (
    id SERIAL PRIMARY KEY,
    fk_group INT,
    data TEXT,
    created_at TIMESTAMP,
    CONSTRAINT fk_group FOREIGN KEY (fk_group) REFERENCES groups(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE review_student (
    id SERIAL PRIMARY KEY,
    fk_teacher INT,
    fk_student INT,
    data TEXT,
    created_at TIMESTAMP,
    CONSTRAINT fk_teacher FOREIGN KEY (fk_teacher) REFERENCES teachers(id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_student FOREIGN KEY (fk_student) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE
);
