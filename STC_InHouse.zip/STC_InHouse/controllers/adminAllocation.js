require('dotenv').config();
const pool = require('../config/db');

const allocateTeacher = async (req, res) => {
    try {
        const { teacherId, groupId } = req.body;

        if (!teacherId) {
            return res.status(400).json({ error: true, message: "Teacher ID is required!" });
        }

        if (!groupId) {
            return res.status(400).json({ error: true, message: "Group ID is required!" });
        }

        const query = `UPDATE groups SET fk_teacher = $1 WHERE id = $2 RETURNING *`;
        const values = [teacherId, groupId];
        const { rows } = await pool.query(query, values);
        if (rows.length === 0) {
            return res.status(400).json({ error: true, message: "Group with this ID doesn't exist!" });
        }
        res.status(200).json({ success: true, message: "Teacher allocated successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}
const deAllocateTeacher = async (req, res) => {
    try {
        const { groupId } = req.body;

        if (!groupId) {
            return res.status(400).json({ error: true, message: "Group ID is required!" });
        }

        const query = `UPDATE groups SET fk_teacher = NULL WHERE id = $1 RETURNING *`;
        const values = [groupId];
        const { rows } = await pool.query(query, values);
        if (rows.length === 0) {
            return res.status(400).json({ error: true, message: "Group with this ID doesn't exist!" });
        }
        res.status(200).json({ success: true, message: "Teacher deallocated successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}
const getNotDomainTeacher = async (req, res) => {
    try {
        const teacher_id = req.params.id; 
        const query = `SELECT d.*
        FROM domains d
        WHERE d.id NOT IN (
            SELECT dt.fk_domain
            FROM domain_teacher dt
            WHERE dt.fk_teacher = $1
        )        
        `;
        const result = await pool.query(query, [teacher_id]);
        res.status(200).json({
            error: false,
            message: "Domains not allocated for teachers fetched successfully.",
            data: result.rows,
        });
    } catch (error) {
        console.log(error); 
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}


const doaminTeacherAllocation = async(req, res) => { 
    try {
        const {domains_id, teacher_id} = req.body;
        console.log(domains_id)
        console.log(teacher_id)
        for (const domain_id of domains_id) {
            const query = `INSERT INTO domain_teacher (fk_domain, fk_teacher) VALUES ($1, $2)`;
            const values = [domain_id, teacher_id];
            await pool.query(query, values);
        }
        res.status(200).json({ success: true, message: "Teacher Domain allocation successfully!" });

    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}
module.exports = {
    allocateTeacher,
    deAllocateTeacher,
    doaminTeacherAllocation,
    getNotDomainTeacher
};
