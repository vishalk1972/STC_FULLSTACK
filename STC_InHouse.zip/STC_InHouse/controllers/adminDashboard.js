require("dotenv").config();
const pool = require("../config/db");

const getTeachers = async (req, res) => {
    try {
        const teachersQuery = `SELECT * FROM teachers`;
        const teachersQueryData = await pool.query(teachersQuery);
        res.status(200).json({
            error: false,
            message: "Teachers fetched successfully.",
            data: teachersQueryData.rows,
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}
const getStudents = async (req, res) => {
    try {
        const studentsQuery = `SELECT * FROM students`;
        const studentsQueryData = await pool.query(studentsQuery);
        res.status(200).json({
            error: false,
            message: "Students fetched successfully.",
            data: studentsQueryData.rows,
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const deleteTeacher = async (req, res) => {
    try {
        const { id } = req.params;

        if (!id) {
            return res.status(400).json({ error: true, message: "Teacher id is required!" });
        }
        const deleteTeacherQuery = `DELETE FROM teachers WHERE id = $1 RETURNING *`;
        const deletedTeacher = await pool.query(deleteTeacherQuery, [id]);
        if (deletedTeacher.rowCount === 0) {
            return res.status(400).json({ error: true, message: "Teacher with this name doesn't exist!" });
        }
        res.status(200).json({
            error: false,
            message: "Teacher deleted successfully.",
            data: deletedTeacher.rows[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const deleteStudents = async (req, res) => {
    try {
        const { id } = req.params;
        if (!id) {
            return res.status(400).json({ error: true, message: "Student id is required!" });
        }
        const deleteTeacherQuery = `DELETE FROM students WHERE id = $1 RETURNING *`;
        const deletedTeacher = await pool.query(deleteTeacherQuery, [id]);
        if (deletedTeacher.rowCount === 0) {
            return res.status(400).json({ error: true, message: "Student with this name doesn't exist!" });
        }
        res.status(200).json({
            error: false,
            message: "Student deleted successfully.",
            data: deletedTeacher.rows[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const getDomainTeacher = async (req, res) => {
    try {
        const domain_id = req.params.id;
        if (!domain_id) {
            return res.status(400).json({ error: true, message: "Domain is required!" });
        }
        const domainTeacherQuery = `SELECT t.* FROM teachers t INNER JOIN domain_teacher dt ON dt.fk_teacher = t.id  WHERE dt.fk_domain = $1`;
        const domainTeacherData = await pool.query(domainTeacherQuery, [domain_id]);
        res.status(200).json({
            error: false,
            message: "Teachers fetched successfully.",
            data: domainTeacherData.rows,
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}
const getDomainStudent = async (req, res) => {
    try {
        const domain = req.params.id;
        if (!domain) {
            return res.status(400).json({ error: true, message: "Domain is required!" });
        }
        const domainStudentQuery = `SELECT s.* FROM students s INNER JOIN domain_student ds ON ds.fk_student = s.id  WHERE ds.fk_domain = $1`;
        const domainStudentData = await pool.query(domainStudentQuery, [domain]);
        res.status(200).json({
            error: false,
            message: "Students fetched successfully.",
            data: domainStudentData.rows,
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}
const getDomainGroup = async (req, res) => {
    try {
        const domain = req.params.id;
        if (!domain) {
            return res.status(400).json({ error: true, message: "Domain is required!" });
        }
        const domainGroupQuery = `SELECT * FROM groups WHERE fk_domain = $1`;
        const domainGroupData = await pool.query(domainGroupQuery, [domain]);
        res.status(200).json({
            error: false,
            message: "Groups fetched successfully.",
            data: domainGroupData.rows,
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const getStudentInGroups = async (req, res) => {
    try {
        const groupId = req.params.id;
        if (!groupId) {
            return res.status(400).json({ error: true, message: "Group ID is required!" });
        }
        const studentGroupQuery = `SELECT s.* FROM students s INNER JOIN student_group sg ON sg.fk_student = s.id WHERE sg.fk_group = $1`;
        const studentGroupData = await pool.query(studentGroupQuery, [groupId]);
        res.status(200).json({
            error: false,
            message: "Students fetched successfully.",
            data: studentGroupData.rows,
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

module.exports = { getTeachers, getStudents, deleteTeacher, deleteStudents, getDomainTeacher, getDomainStudent, getDomainGroup, getStudentInGroups};