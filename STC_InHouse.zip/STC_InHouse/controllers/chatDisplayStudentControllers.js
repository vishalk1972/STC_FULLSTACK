require("dotenv").config();
const pool = require("../config/db");

const getAllChats = async (req, res) => {
    try {
        const fk_student = req.student.id;
        const getGroupId = `select fk_group from student_group where fk_student = $1`;
        const groupIdData = await pool.query(getGroupId, [fk_student]);
        const groupId = groupIdData.rows[0].fk_group;
        const chatsQuery = `SELECT 
        fd.id,
        fd.fk_group,
        fd.teacher_uploaded,
        fd.fk_student,
        CASE 
            WHEN fd.teacher_uploaded = TRUE THEN t.name 
            ELSE concat(s.first_name, ' ', s.last_name) 
        END AS uploader_name,
        fd.data,
        fd.is_file,
        fd.uploaded_at
    FROM 
        datas fd
    INNER JOIN 
        groups g ON fd.fk_group = g.id
    LEFT JOIN 
        teachers t ON g.fk_teacher = t.id AND fd.teacher_uploaded = TRUE
    LEFT JOIN 
        students s ON fd.fk_student = s.id AND fd.teacher_uploaded = FALSE
    WHERE fd.fk_group = $1 ORDER BY uploaded_at  
    `;
        const chatsQueryData = await pool.query(chatsQuery, [groupId]);
        res.status(200).json({
            error: false,
            message: "Chats fetched successfully.",
            data: chatsQueryData.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

module.exports = { getAllChats };