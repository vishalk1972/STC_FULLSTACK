const pool = require("../config/db");

const createDomain = async (req, res) => {
    try {
        const { domain_name } = req.body;

        if (!domain_name) {
            return res.status(400).json({ error: true, message: "Domain name is required!" });
        }

        const domainExistsQuery = `SELECT * FROM domains WHERE domain_name = $1`;
        const domainExistsResult = await pool.query(domainExistsQuery, [domain_name]);

        if (domainExistsResult.rowCount > 0) {
            return res.status(400).json({ error: true, message: "Domain with this name already exists!" });
        }

        const insertDomainQuery = `INSERT INTO domains (domain_name) VALUES ($1) RETURNING *`;
        const insertedDomain = await pool.query(insertDomainQuery, [domain_name]);

        res.status(200).json({
            error: false,
            message: "Domain created successfully.",
            data: insertedDomain.rows[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const deleteDomains = async (req, res) => {
    try {
        const { domain_name } = req.params;

        if (!domain_name) {
            return res.status(400).json({ error: true, message: "Domain name is required!" });
        }

        const deleteDomainQuery = `DELETE FROM domains WHERE domain_name = $1 RETURNING *`;
        const deletedDomain = await pool.query(deleteDomainQuery, [domain_name]);

        if (deletedDomain.rowCount === 0) {
            return res.status(400).json({ error: true, message: "Domain with this name doesn't exist!" });
        }

        res.status(200).json({
            error: false,
            message: "Domain deleted successfully.",
            data: deletedDomain.rows[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const getDomains = async (req, res) => {
    try {
        const domainsQuery = `SELECT * FROM domains`;
        const domains = await pool.query(domainsQuery);

        res.status(200).json({
            error: false,
            message: "Domains fetched successfully.",
            data: domains.rows
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

module.exports = { createDomain, deleteDomains, getDomains };
