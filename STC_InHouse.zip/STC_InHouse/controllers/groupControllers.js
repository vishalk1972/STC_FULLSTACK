const pool = require("../config/db");

const createGroup = async (req, res) => {
    try {
        const roll_number = req.student.roll_number;
        const { remaining_roll_numbers, domain_id } = req.body;
        const studentQuery = 'SELECT id FROM students WHERE roll_number = $1';
        const studentResult = await pool.query(studentQuery, [roll_number]);
        const studentId = studentResult.rows[0].id;
        if (!studentId) {
            return res.status(400).json({ error: true, message: 'Invalid roll number' });
        }
        const existingGroupQuery = 'SELECT fk_group FROM student_group WHERE fk_student = $1';
        const existingGroupResult = await pool.query(existingGroupQuery, [studentId]);
        if (existingGroupResult.rows.length > 0) {
            return res.status(400).json({ error: true, message: 'You are already a member of a group.' });
        }
        if (remaining_roll_numbers.length > 2) {
            return res.status(400).json({ error: true, message: 'A group can have a maximum of 3 members' });
        }

        const createGroupQuery = 'INSERT INTO groups (fk_domain, group_name) VALUES ($1, $2) RETURNING id';
        const groupResult = await pool.query(createGroupQuery, [domain_id, 'grp']);
        const groupId = groupResult.rows[0].id;
        const updatedGroupName = `grp${groupId}`;
        const updateGroupNameQuery = 'UPDATE groups SET group_name = $1 WHERE id = $2';
        await pool.query(updateGroupNameQuery, [updatedGroupName, groupId]);
        await pool.query('INSERT INTO student_group (fk_student, fk_group) VALUES ($1, $2)', [studentId, groupId]);
        const uniqueMemberIds = new Set([studentId]);
        for (const member_roll_number of remaining_roll_numbers) {
            const memberQuery = 'SELECT id FROM students WHERE roll_number = $1';
            const memberResult = await pool.query(memberQuery, [member_roll_number]);
            const memberId = memberResult.rows[0].id;
            if (!memberId) {
                return res.status(400).json({ error: true, message: `Student with roll number ${member_roll_number} is not registered` });
            }
            const existingMemberGroupQuery = 'SELECT fk_group FROM student_group WHERE fk_student = $1';
            const existingMemberGroupResult = await pool.query(existingMemberGroupQuery, [memberId]);
            if (existingMemberGroupResult.rows.length > 0) {
                return res.status(400).json({ error: true, message: `Student with roll number ${member_roll_number} is already in a group` });
            }
            if (uniqueMemberIds.has(memberId)) {
                return res.status(400).json({ error: true, message: `Student with roll number ${member_roll_number} is already added to the group` });
            }
            uniqueMemberIds.add(memberId);
            await pool.query('INSERT INTO student_group (fk_student, fk_group) VALUES ($1, $2)', [memberId, groupId]);
        }
        if (uniqueMemberIds.size > 3) {
            return res.status(400).json({ error: true, message: 'A group can have a maximum of 3 unique members' });
        }
        res.status(200).json({ message: 'Group created and members added successfully', group_id: groupId });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: 'Internal Server Error!' });
    }
};

const deleteGroup = async (req, res) => {
    try {
        const groupId = req.params.id;

        if (!groupId) {
            return res.status(400).json({ error: true, message: "Group ID is required!" });
        }

        const query = `DELETE FROM groups WHERE id = $1`;
        const values = [groupId];
        await pool.query(query, values);
        res.status(200).json({ success: true, message: "Group deleted successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const getAllGroups = async (req, res) => {
    try {
        const query = `SELECT * FROM groups`;
        const { rows } = await pool.query(query);
        res.status(200).json({ groups: rows });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const getGroupById = async (req, res) => {
    try {
        const groupId = req.params.id;

        if (!groupId) {
            return res.status(400).json({ error: true, message: "Group ID is required!" });
        }

        const query = `SELECT * FROM groups WHERE id = $1`;
        const values = [groupId];
        const { rows } = await pool.query(query, values);
        if (rows.length === 0) {
            return res.status(404).json({ error: true, message: "Group not found!" });
        }
        res.status(200).json({ group: rows[0] });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const updateGroupName = async (req, res) => {
    try {
        const { groupId, group_name } = req.body;

        if (!groupId) {
            return res.status(400).json({ error: true, message: "Group ID is required!" });
        }

        if (!group_name) {
            return res.status(400).json({ error: true, message: "Group name is required!" });
        }

        const query = `UPDATE groups SET group_name = $1 WHERE id = $2`;
        const values = [group_name, groupId];
        await pool.query(query, values);
        res.status(200).json({ success: true, message: "Group name updated successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

module.exports = { createGroup, deleteGroup, getAllGroups, getGroupById, updateGroupName };
