const pool = require("../config/db");

const createGroupReview = async (req, res) => {
    try {
        const { group_id, review } = req.body;
        const created_at = new Date(); 
        const newReviewQuery = `
            INSERT INTO review_group (fk_group, data, created_at) 
            VALUES ($1, $2, $3)
            RETURNING *`;
        const newReviewValues = [group_id, review, created_at];
        const newReview = await pool.query(newReviewQuery, newReviewValues);

        res.json({
            error: false,
            message: "Group review created successfully.",
            data: newReview.rows[0]
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

const getGroupReviews = async (req, res) => {
    try {
        const { group_id } = req.body;
        const getReviewsQuery = `SELECT * FROM review_group WHERE fk_group = $1`;
        const reviews = await pool.query(getReviewsQuery, [group_id]);

        res.json({
            error: false,
            message: "Group reviews fetched successfully.",
            data: reviews.rows
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

const deleteGroupReview = async (req, res) => {
    try {
        const { review_id } = req.body;
        const deleteReviewQuery = `DELETE FROM review_group WHERE id = $1`;
        const deleteReviewValues = [review_id];
        const deletedReview = await pool.query(deleteReviewQuery, deleteReviewValues);

        res.json({
            error: false,
            message: "Group review deleted successfully.",
            data: deletedReview.rows[0]
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

const createStudentReview = async (req, res) => {
    try {
        const { fk_student, data } = req.body;
        const fk_teacher = req.teacher.id;
        const created_at = new Date();
        const newReviewQuery = `
            INSERT INTO review_student (fk_teacher, fk_student, data, created_at) 
            VALUES ($1, $2, $3, $4)
            RETURNING *`;
        const newReviewValues = [fk_teacher, fk_student, data, created_at];
        const newReview = await pool.query(newReviewQuery, newReviewValues);

        res.status(201).json({
            error: false,
            message: "Student review created successfully.",
            data: newReview.rows[0]
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

const getStudentReviews = async (req, res) => {
    try {
        const { fk_student } = req.body;
        const getReviewsQuery = `SELECT * FROM review_student WHERE fk_student = $1`;
        const reviews = await pool.query(getReviewsQuery, [fk_student]);

        res.status(200).json({
            error: false,
            message: "Student reviews fetched successfully.",
            data: reviews.rows
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

const deleteStudentReview = async (req, res) => {
    try {
        const { id } = req.params;
        const deleteReviewQuery = `
            DELETE FROM review_student
            WHERE id = $1
            RETURNING *`;
        const deletedReview = await pool.query(deleteReviewQuery, [id]);

        res.status(200).json({
            error: false,
            message: "Student review deleted successfully.",
            data: deletedReview.rows[0]
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

module.exports = {
    createGroupReview,
    getGroupReviews,
    deleteGroupReview,
    createStudentReview,
    getStudentReviews,
    deleteStudentReview
};
