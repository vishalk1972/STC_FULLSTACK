require("dotenv").config();
const bcrypt = require("bcrypt");
const pool = require("../config/db");
const generateStudentToken = require("../utils/studentToken");

const signup = async (req, res) => {
    const {first_name, last_name, email, mobile_number, roll_number, reg_number, password} = req.body;

    // if (!password || !first_name || !last_name || !email || !mobile_number || !roll_number || !reg_number || !fk_group || !fk_domain) {
    //     return res
    //         .status(400)
    //         .json({ error: true, message: "All fields are required!" });
    // }

    try {
        const hashedPassword = await bcrypt.hash(
            password,
            Number(process.env.SALT)
        );

        const studentQuery = `INSERT INTO students ( first_name, last_name, email, mobile_number, roll_number, reg_number, password) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`;
        const studentQueryParams = [first_name, last_name, email, mobile_number, roll_number, reg_number, hashedPassword];
        const studentQueryData = await pool.query(studentQuery, studentQueryParams);

        const token = await generateStudentToken(studentQueryData.rows[0].id);
        const student = studentQueryData.rows[0];
        delete student.password;
        res.status(200).json({
            error: false,
            message: "student Login Successfull.",
            data: {
                token,
                student,
            },
        });
    } catch (err) {
        if (err.code === "23505") {
            res.status(400).json({
                error: true,
                message: "student with this details already exists!",
            });
        } else {
            console.log(err);
            res.status(500).json({ error: true, message: "Internal Server Error!" });
        }
    }
};


const login = async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res
            .status(400)
            .json({ error: true, message: "All fields are required!" });
    }

    try {
        const studentQuery = `SELECT * FROM students WHERE email = $1`;
        const studentQueryParams = [email];
        const studentQueryData = await pool.query(studentQuery, studentQueryParams);

        if (studentQueryData.rowCount === 1) {
            const auth = await bcrypt.compare(
                password,
                studentQueryData.rows[0].password
            );
            if (auth) {
                const token = await generateStudentToken(studentQueryData.rows[0].id);
                const student = studentQueryData.rows[0];
                delete student.password;
                res.status(200).json({
                    error: false,
                    message: "Student Login Successful.",
                    data: {
                        token,
                        student,
                    },
                });
            } else {
                res.status(400).json({
                    error: true,
                    message: "Password Not Correct!",
                });
            }
        } else {
            res.status(404).json({ error: true, message: "Student Not Found!" });
        }
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

const logout = async (req, res) => {
    try {
        const token = req.token;
        const query = `DELETE from student_token WHERE token = $1`;
        const queryParams = [token];
        const queryData = await pool.query(query, queryParams);

        res.status(200).json({ error: false, message: "Logout Successfull." });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal server error!" });
    }
};

module.exports = { signup, login, logout};