const pool = require("../config/db");

const getStudentDetails = async (req, res) => {
    try {
        const studentId = req.student.id;
        const studentQuery = `SELECT * FROM students WHERE id = $1`;
        const studentQueryData = await pool.query(studentQuery, [studentId]);
        res.status(200).json({
            error: false,
            message: "Student details fetched successfully.",
            data: studentQueryData.rows[0],
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const getStudentGroups = async (req, res) => {
    try {
        const fk_group = req.student.id;
        const groupsQuery = `SELECT * FROM groups INNER JOIN student_group ON groups.id = student_group.fk_group WHERE student_group.fk_student = $1`;
        const groupsQueryData = await pool.query(groupsQuery, [fk_group]);
        res.status(200).json({
            error: false,
            message: "Groups fetched successfully.",
            data: groupsQueryData.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}

const getStudentsUnderGroup = async (req, res) => {
    try {
        const studentId = req.student.id;
        const getGroupId = `select fk_group from student_group where fk_student = $1`;
        const groupIdData = await pool.query(getGroupId, [studentId]);
        const groupId = groupIdData.rows[0].fk_group;
        const studentsQuery = `SELECT s.* FROM students s INNER JOIN student_group sg ON s.id = sg.fk_student INNER JOIN groups g ON sg.fk_group = g.id WHERE g.id = $1`;
        const studentsQueryData = await pool.query(studentsQuery, [groupId]);
        res.status(200).json({
            error: false,
            message: "Students fetched successfully.",
            data: studentsQueryData.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

module.exports = { getStudentDetails, getStudentGroups, getStudentsUnderGroup };