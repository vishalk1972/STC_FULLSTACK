const pool = require("../config/db");

const createSuggestion = async (req, res) => {
    try {

        const { datas } = req.body;
        const fk_student = req.student.id;
        const uploaded_at = new Date();
        const getGroupId = `select fk_group from student_group where fk_student = $1`;
        const groupIdData = await pool.query(getGroupId, [fk_student]);
        const groupId = groupIdData.rows[0].fk_group;
        const newSuggestionQuery = `
            INSERT INTO datas (fk_group, teacher_uploaded, fk_student, data, is_file, uploaded_at) 
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *`;
        const newSuggestionValues = [groupId, false, fk_student, datas, false, uploaded_at];
        const newSuggestion = await pool.query(newSuggestionQuery, newSuggestionValues);

        res.status(201).json({
            error: false,
            message: "Suggestion created successfully.",
            data: newSuggestion.rows[0]
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({
            error: true,
            message: "Internal Server Error!"
        });
    }
};

const deleteSuggestion = async (req, res) => {
    try {
        const { delete_id } = req.body;
        const deleteSuggestionQuery = `
            DELETE FROM datas 
            WHERE id = $1
            RETURNING *`;
        const deletedSuggestion = await pool.query(deleteSuggestionQuery, [delete_id]);

        res.status(200).json({
            error: false,
            message: "Suggestion deleted successfully.",
            data: deletedSuggestion.rows[0]
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({
            error: true,
            message: "Internal Server Error!"
        });
    }
};

module.exports = { createSuggestion, deleteSuggestion };