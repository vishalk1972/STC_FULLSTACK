require("dotenv").config();
const bcrypt = require("bcrypt");
const pool = require("../config/db");
const generateTeacherToken = require("../utils/teacherToken");

const signup = async (req, res) => {
    const { name, email, mobile_number, reg_number, designation, password} = req.body;

    // if (!password || !name || !email || !mobile_number || !reg_number || !fk_domain) {
    //     return res
    //         .status(400)
    //         .json({ error: true, message: "All fields are required!" });
    // }

    try {
        const hashedPassword = await bcrypt.hash(
            password,
            Number(process.env.SALT)
        );
    
        const teacherQuery = `INSERT INTO teachers (name, email, mobile_number, reg_number, designation, password) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`;
        const teacherQueryParams = [name, email, mobile_number, reg_number, designation, hashedPassword];
        const teacherQueryData = await pool.query(teacherQuery, teacherQueryParams);

        const token = await generateTeacherToken(teacherQueryData.rows[0].id);
        const teacher = teacherQueryData.rows[0];
        delete teacher.password;
        res.status(200).json({
            error: false,
            message: "Teacher Login Successful.",
            data: {
                token,
                teacher,
            },
        });
    } catch (err) {
        if (err.code === "23505") {
            res.status(400).json({
                error: true,
                message: "Teacher with these details already exists!",
            });
        } else {
            console.log(err);
            res.status(500).json({ error: true, message: "Internal Server Error!" });
        }
    }
};


const login = async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res
            .status(400)
            .json({ error: true, message: "All fields are required!" });
    }

    try {
        const teacherQuery = `SELECT * FROM teachers WHERE email = $1`;
        const teacherQueryParams = [email];
        const teacherQueryData = await pool.query(teacherQuery, teacherQueryParams);

        if (teacherQueryData.rowCount === 1) {
            const auth = await bcrypt.compare(
                password,
                teacherQueryData.rows[0].password
            );
            if (auth) {
                const token = await generateTeacherToken(teacherQueryData.rows[0].id);
                const teacher = teacherQueryData.rows[0];
                delete teacher.password;
                res.status(200).json({
                    error: false,
                    message: "teacher Login Successful.",
                    data: {
                        token,
                        teacher,
                    },
                });
            } else {
                res.status(400).json({
                    error: true,
                    message: "Password Not Correct!",
                });
            }
        } else {
            res.status(404).json({ error: true, message: "teacher Not Found!" });
        }
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};


const logout = async (req, res) => {
    try {
        const token = req.token;
        const query = `DELETE from teacher_token WHERE token = $1`;
        const queryParams = [token];
        const queryData = await pool.query(query, queryParams);

        res.status(200).json({ error: false, message: "Logout Successfull." });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal server error!" });
    }
};

module.exports = { signup, login, logout };