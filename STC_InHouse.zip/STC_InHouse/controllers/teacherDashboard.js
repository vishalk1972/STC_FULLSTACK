require("dotenv").config();
const pool = require("../config/db");

const getTeachers = async (req, res) => {
    try {
        const teacherId = req.teacher.id;
        const teachersQuery = `SELECT * FROM teachers id = $1 `;
        const teachersQueryData = await pool.query(teachersQuery,[teacherId]);
        res.status(200).json({
            error: false,
            message: "Teachers fetched successfully.",
            data: teachersQueryData.rows,
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}
const getTeacherDomains = async (req, res) => {
    try {
        const teacherId = req.teacher.id;
        const domainsQuery = `SELECT d.* from domains d INNER JOIN domain_teacher dt ON d.id = dt.fk_domain WHERE dt.fk_teacher = $1`;
        const domainsQueryData = await pool.query(domainsQuery, [teacherId]);
        res.status(200).json({
            error: false,
            message: "Domains fetched successfully.",
            data: domainsQueryData.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
}
const getTeacherGroups = async (req, res) => {
    try {
        const teacherId = req.teacher.id;
        const groupsQuery = `SELECT * FROM groups g WHERE fk_teacher = $1`;
        const groupsQueryData = await pool.query(groupsQuery, [teacherId]);
        res.status(200).json({
            error: false,
            message: "Groups fetched successfully.",
            data: groupsQueryData.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

const getStudentsUnderTeacher = async (req, res) => {
    try {
        const teacherId = req.teacher.id;
        const studentsQuery = `SELECT s.* FROM students s INNER JOIN student_group sg ON sg.fk_student = s.id INNER JOIN groups g ON g.id = sg.fk_group WHERE g.fk_teacher = $1`;
        const studentsQueryData = await pool.query(studentsQuery, [teacherId]);
        res.status(200).json({
            error: false,
            message: "Students fetched successfully.",
            data: studentsQueryData.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

const getStudentsUnderGroup = async (req, res) => {
    try {
        const groupId = req.params.groupId;
        const teacherId = req.teacher.id;
        const studentsQuery = `SELECT s.* FROM students s INNER JOIN student_group sg ON sg.fk_student = s.id INNER JOIN groups g ON g.id = sg.fk_group WHERE g.fk_teacher = $1 AND g.id = $2`;
        const studentsQueryData = await pool.query(studentsQuery, [teacherId,groupId]);
        res.status(200).json({
            error: false,
            message: "Students fetched successfully.",
            data: studentsQueryData.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};

module.exports = { getTeachers,getTeacherDomains, getTeacherGroups, getStudentsUnderTeacher, getStudentsUnderGroup};
