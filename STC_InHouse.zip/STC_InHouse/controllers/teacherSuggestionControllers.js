const pool = require("../config/db");

const createSuggestion = async (req, res) => {
    try {

        const { fk_group, data } = req.body;
        const uploaded_at = new Date();
        const newSuggestionQuery = `
            INSERT INTO datas (fk_group, teacher_uploaded, fk_student, data, is_file, uploaded_at) 
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *`;
        const newSuggestionValues = [fk_group, true, null, data, false, uploaded_at];
        const newSuggestion = await pool.query(newSuggestionQuery, newSuggestionValues);

        res.status(201).json({
            error: false,
            message: "Suggestion created successfully.",
            data: newSuggestion.rows[0]
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({
            error: true,
            message: "Internal Server Error!"
        });
    }
};

const deleteSuggestion = async (req, res) => {
    try {
        const { delete_id } = req.body;
        const deleteSuggestionQuery = `
            DELETE FROM suggestions 
            WHERE id = $1
            RETURNING *`;
        const deletedSuggestion = await pool.query(deleteSuggestionQuery, [delete_id]);

        res.status(200).json({
            error: false,
            message: "Suggestion deleted successfully.",
            data: deletedSuggestion.rows[0]
        });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({
            error: true,
            message: "Internal Server Error!"
        });
    }
};

module.exports = { createSuggestion, deleteSuggestion };