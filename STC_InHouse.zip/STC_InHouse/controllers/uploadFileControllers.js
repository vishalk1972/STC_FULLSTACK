require("dotenv").config();
const pool = require("../config/db");
const admin = require("firebase-admin");
const serviceAccount = require("../config/firebase");
const ALLOWED_FILE_TYPES = [
    'image/jpeg',
    'image/png',
    'application/pdf',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/msword'
];
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    storageBucket: process.env.STORAGE_BUCKET_URL,
});
const bucket = admin.storage().bucket();

const uploadFile = async (req, res) => {
    try {
        const file = req.file;
        const fk_group  = req.body;
        const uploaded_at = new Date();

        if (!file || !ALLOWED_FILE_TYPES.includes(file.mimetype)) {
            return res.status(400).json({
                error: true,
                message: "Please upload a valid file (JPEG/PNG/PDF/PPT) before proceeding.",
            });
        }

        const timestamp = Date.now();
        const remoteFilePath = `files/${timestamp}_${file.originalname}`;

        const fileUpload = bucket.file(remoteFilePath);
        const blobStream = fileUpload.createWriteStream();

        blobStream.on("error", (err) => {
            console.log(err);
            return res.status(500).json({ error: true, message: "Error uploading file." });
        });
        blobStream.on("finish", async () => {
            try {
                const downloadURL = await fileUpload.getSignedUrl({
                    action: "read",
                    expires: "03-09-2491",
                });
                const newFileQuery = `
                    INSERT INTO datas (fk_group, teacher_uploaded, fk_student, data, is_file, uploaded_at) 
                    VALUES ($1, $2, $3, $4, $5, $6)
                    RETURNING *`;
                const newFileValues = [fk_group, true, null, downloadURL, true, uploaded_at];
                const newFile = await pool.query(newFileQuery, newFileValues);

                res.status(200).json({
                    error: false,
                    message: "File uploaded successfully.",
                });
            } catch (queryError) {
                console.log(queryError);
                res.status(500).json({ error: true, message: "Error updating database." });
            }
        });
        blobStream.end(file.buffer);
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};


const uploadStudentFile = async (req, res) => {
    try {
        const file = req.file;
        const fk_student  = req.student.id;
        const getGroupId = `select fk_group from student_group where fk_student = $1`;
        const groupIdData = await pool.query(getGroupId, [fk_student]);
        const groupId = groupIdData.rows[0].fk_group;
        const uploaded_at = new Date();
    
        if (!file || !ALLOWED_FILE_TYPES.includes(file.mimetype)) {
            return res.status(400).json({
                error: true,
                message: "Please upload a valid file (JPEG/PNG/PDF/PPT) before proceeding.",
            });
        }

        const timestamp = Date.now();
        const remoteFilePath = `files/${timestamp}_${file.originalname}`;

        const fileUpload = bucket.file(remoteFilePath);
        const blobStream = fileUpload.createWriteStream();

        blobStream.on("error", (err) => {
            console.log(err);
            return res.status(500).json({ error: true, message: "Error uploading file." });
        });
        blobStream.on("finish", async () => {
            try {
                const downloadURL = await fileUpload.getSignedUrl({
                    action: "read",
                    expires: "03-09-2491",
                });
                const newFileQuery = `
                    INSERT INTO datas (fk_group, teacher_uploaded, fk_student, data, is_file, uploaded_at) 
                    VALUES ($1, $2, $3, $4, $5, $6)
                    RETURNING *`;
                const newFileValues = [fk_group, false, fk_student, downloadURL,true, uploaded_at];
                const newFile = await pool.query(newFileQuery, newFileValues);

                res.status(200).json({
                    error: false,
                    message: "File uploaded successfully.",
                });
            } catch (queryError) {
                console.log(queryError);
                res.status(500).json({ error: true, message: "Error updating database." });
            }
        });
        blobStream.end(file.buffer);
    } catch (error) {
        console.log(error);
        res.status(500).json({ error: true, message: "Internal Server Error!" });
    }
};


module.exports = { uploadFile, uploadStudentFile };
