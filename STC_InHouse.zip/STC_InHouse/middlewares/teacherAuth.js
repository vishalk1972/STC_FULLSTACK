const pool = require("../config/db");

const isTeacherAuthenticated = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
      return res
        .status(401)
        .json({ error: true, message: "Not Authenticated!" });
    }

    const token = authHeader.replace("Bearer ", "");
    const tokenQuery = `SELECT * FROM teacher_token WHERE token = $1`;
    const tokenQueryParams = [token];
    const tokenQueryData = await pool.query(tokenQuery, tokenQueryParams);

    if (tokenQueryData.rowCount < 1) {
      return res.status(401).json({ error: true, message: "Invalid Token!" });
    }

    const teacherId = tokenQueryData.rows[0].fk_teacher;
    const teacherQuery = `SELECT * FROM teachers WHERE id = $1`;
    const teacherQueryParams = [teacherId];
    const teacherQueryData = await pool.query(teacherQuery, teacherQueryParams);

    req.teacher = teacherQueryData.rows[0];
    req.token = token;
    next();
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: true, message: "Internal Server Error!" });
  }
};

module.exports = { isTeacherAuthenticated };