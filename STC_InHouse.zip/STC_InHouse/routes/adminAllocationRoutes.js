const express = require("express");
const router = express.Router();

const {
    allocateTeacher,
    deAllocateTeacher,
    doaminTeacherAllocation,
    getNotDomainTeacher
} = require("../controllers/adminAllocation");

const { isAdminAuthenticated } = require("../middlewares/adminAuth");

router.get("/domainNotTeacher/:id",isAdminAuthenticated,getNotDomainTeacher);
router.post("/doaminTeacherAllocation", isAdminAuthenticated, doaminTeacherAllocation);
router.post("/allocateTeacher", isAdminAuthenticated, allocateTeacher);
router.post("/deAllocateTeacher", isAdminAuthenticated, deAllocateTeacher);

module.exports = router;