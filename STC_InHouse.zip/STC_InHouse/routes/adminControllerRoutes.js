const express = require("express");
const router = express.Router();
const {
  signup,
  logout,
  login,
} = require("../controllers/adminControllers");

const { isAdminAuthenticated } = require("../middlewares/adminAuth");

router.post("/signup", signup);
router.post("/login", login);
router.post("/logout", isAdminAuthenticated, logout);

module.exports = router;