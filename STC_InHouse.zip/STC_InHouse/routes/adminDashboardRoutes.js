const express = require("express");
const router = express.Router();
const { getTeachers, getStudents, deleteTeacher, deleteStudents,getDomainTeacher,getDomainStudent,getStudentInGroups,getDomainGroup } = require("../controllers/adminDashboard");
const { isAdminAuthenticated } = require("../middlewares/adminAuth");
router.get("/teachers", isAdminAuthenticated, getTeachers);
router.get("/students", isAdminAuthenticated, getStudents);
router.delete("/deleteTeacher/:id", isAdminAuthenticated, deleteTeacher);
router.delete("/deleteStudent/:id", isAdminAuthenticated, deleteStudents);
router.get("/getDomainTeacher/:id",isAdminAuthenticated,getDomainTeacher);
router.get("/getDomainStudent/:id",isAdminAuthenticated,getDomainStudent);
router.get("/getDomainGroup/:id",isAdminAuthenticated,getDomainGroup);
router.get("/getStudentInGroups/:id",isAdminAuthenticated,getStudentInGroups);

module.exports = router;
