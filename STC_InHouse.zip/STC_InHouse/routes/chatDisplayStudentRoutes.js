const express = require("express");
const router = express.Router();

const { getAllChats } = require("../controllers/chatDisplayStudentControllers");
const { isStudentAuthenticated } = require("../middlewares/studentAuth");

router.get("/group", isStudentAuthenticated, getAllChats);

module.exports = router;
