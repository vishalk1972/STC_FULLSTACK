const express = require("express");
const router = express.Router();

const { getAllChats } = require("../controllers/chatDisplayTeacherControllers");
const { isTeacherAuthenticated } = require("../middlewares/teacherAuth");

router.get("/group/:id", isTeacherAuthenticated, getAllChats);

module.exports = router;