const express = require("express");
const router = express.Router();
const { createDomain, deleteDomains, getDomains } = require("../controllers/domainControllers");
const { isAdminAuthenticated } = require("../middlewares/adminAuth");

router.post("/create", isAdminAuthenticated, createDomain);
router.delete("/delete/:domain_name", isAdminAuthenticated, deleteDomains);
router.get("/", isAdminAuthenticated, getDomains);

module.exports = router;
