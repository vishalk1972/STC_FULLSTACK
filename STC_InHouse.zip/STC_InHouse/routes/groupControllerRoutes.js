const express = require("express");
const router = express.Router();
const {
    createGroup,
    deleteGroup,
    getAllGroups,
    getGroupById,
    updateGroupName
} = require("../controllers/groupControllers");

const { isAdminAuthenticated } = require("../middlewares/adminAuth");
const {isStudentAuthenticated} = require("../middlewares/studentAuth");
router.post("/create", isStudentAuthenticated, createGroup);
router.delete("/delete/:id", isAdminAuthenticated, deleteGroup);
router.get("/", isAdminAuthenticated, getAllGroups);
router.get("/:id", isAdminAuthenticated, getGroupById);
router.put("/update", isAdminAuthenticated, updateGroupName);

module.exports = router;
