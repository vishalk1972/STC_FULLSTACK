const express = require('express');
const router = express.Router();
const { createGroupReview,
    getGroupReviews,
    deleteGroupReview,
    createStudentReview,
    getStudentReviews,
    deleteStudentReview } = require('../controllers/reviewControllers');

const { isTeacherAuthenticated } = require("../middlewares/teacherAuth");

router.post("/createGroup", isTeacherAuthenticated, createGroupReview);
router.get("/getGroup", isTeacherAuthenticated, getGroupReviews);
router.delete("/deleteGroup", isTeacherAuthenticated, deleteGroupReview);
router.post("/createStudent", isTeacherAuthenticated, createStudentReview);
router.get("/getStudent", isTeacherAuthenticated, getStudentReviews);
router.delete("/deleteStudent", isTeacherAuthenticated, deleteStudentReview);


module.exports = router;