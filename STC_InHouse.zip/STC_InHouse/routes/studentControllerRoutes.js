const express = require("express");
const router = express.Router();
const {
  signup,
  logout,
  login,
} = require("../controllers/studentControllers");

const { isStudentAuthenticated } = require("../middlewares/studentAuth");

router.post("/signup", signup);
router.post("/login", login);
router.post("/logout", isStudentAuthenticated, logout);

module.exports = router;