const express = require('express');
const router = express.Router();
const { getStudentDetails, getStudentGroups,getStudentsUnderGroup } = require('../controllers/studentDashboard');

const { isStudentAuthenticated } = require("../middlewares/studentAuth");

router.get('/studentDetails', isStudentAuthenticated, getStudentDetails);
router.get("/studentsUnderGroup", isStudentAuthenticated,getStudentsUnderGroup);
router.get('/studentGroups', isStudentAuthenticated, getStudentGroups);

module.exports = router;