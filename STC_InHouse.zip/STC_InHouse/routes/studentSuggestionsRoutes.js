const express = require('express');
const router = express.Router();
const { createSuggestion,
    deleteSuggestion } = require('../controllers/studentSuggestionControllers');

const { isStudentAuthenticated } = require("../middlewares/studentAuth");

router.post("/create", isStudentAuthenticated, createSuggestion);
router.delete("/delete", isStudentAuthenticated, deleteSuggestion);

module.exports = router;