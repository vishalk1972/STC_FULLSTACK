const express = require("express");
const router = express.Router();
const {
  signup,
  logout,
  login,
} = require("../controllers/teacherControllers");

const { isTeacherAuthenticated } = require("../middlewares/teacherAuth");

router.post("/signup", signup);
router.post("/login", login);
router.post("/logout", isTeacherAuthenticated, logout);

module.exports = router;