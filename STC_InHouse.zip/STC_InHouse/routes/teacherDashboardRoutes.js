const express = require("express");
const router = express.Router();
const { getTeachers,getTeacherDomains, getTeacherGroups, getStudentsUnderTeacher, getStudentsUnderGroup} = require("../controllers/teacherDashboard");

const { isTeacherAuthenticated } = require("../middlewares/teacherAuth");

router.get("/teachers", isTeacherAuthenticated, getTeachers);
router.get("/teacherDomains", isTeacherAuthenticated, getTeacherDomains);
router.get("/teacherGroups", isTeacherAuthenticated, getTeacherGroups);
router.get("/studentsUnderTeacher", isTeacherAuthenticated, getStudentsUnderTeacher);
router.get("/studentsUnderGroup/:groupId", isTeacherAuthenticated, getStudentsUnderGroup);

module.exports = router;