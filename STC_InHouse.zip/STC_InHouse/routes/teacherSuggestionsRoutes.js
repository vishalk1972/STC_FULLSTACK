const express = require('express');
const router = express.Router();
const { createSuggestion,
    deleteSuggestion } = require('../controllers/teacherSuggestionControllers');

const { isTeacherAuthenticated } = require("../middlewares/teacherAuth");

router.post("/create", isTeacherAuthenticated, createSuggestion);
router.delete("/delete", isTeacherAuthenticated, deleteSuggestion);

module.exports = router;
