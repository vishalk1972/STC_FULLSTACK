const express = require("express");
const router = express.Router();
const multer = require("multer");
const { isTeacherAuthenticated } = require("../middlewares/teacherAuth");
const { isStudentAuthenticated } = require("../middlewares/studentAuth");

const upload = multer({ storage: multer.memoryStorage() });
const {uploadFile , uploadStudentFile} = require("../controllers/uploadFileControllers");

router.post("/file", upload.single("file"), isTeacherAuthenticated, uploadFile);
router.post("/studentFile", upload.single("file"), isStudentAuthenticated, uploadStudentFile);

module.exports = router;
