const express = require("express");
const cors = require("cors");
const app = express();
const cron = require('node-cron');
const port = process.env.PORT || 8000;
const axios = require('axios');
app.use(express.json());
app.use(cors());
app.use(express.urlencoded({ extended: true }));

app.use("/api/adminAllocation", require("./routes/adminAllocationRoutes"));
app.use("/api/admin", require("./routes/adminControllerRoutes"));
app.use("/api/student", require("./routes/studentControllerRoutes"));
app.use("/api/teacher", require("./routes/teacheControllerRoutes"));
app.use("/api/domain", require("./routes/domainControllerRoutes"));
app.use("/api/group", require("./routes/groupControllerRoutes"));
app.use("/api/adminDashboard", require("./routes/adminDashboardRoutes"));
app.use("/api/teacherDashboard", require("./routes/teacherDashboardRoutes"));
app.use("/api/studentDashboard", require("./routes/studentDashboardRoutes"));
app.use("/api/review", require("./routes/reviewControllerRoutes"));
app.use("/api/studentSuggestions", require("./routes/studentSuggestionsRoutes"));
app.use("/api/teacherSuggestions", require("./routes/teacherSuggestionsRoutes"));
app.use("/api/uploadFile", require("./routes/uploadFileRoutes"));
app.use("/api/teacherChat", require("./routes/chatDisplayTeacherRoutes"));
app.use("/api/studentChat", require("./routes/chatDisplayStudentRoutes"));
app.get("/", (req, res) => {
  res.status(200).json("Server is running....");
});

app.get("/ping", (req, res) => {
  res.status(200).json("pong....");
});
app.listen(port, () => console.log(`Server is running on port ${port}`));

const API_ENDPOINT = "https://stc-e9a8.onrender.com/ping";

const makeApiRequest = async () => {
  try {
    const response = await axios.get(API_ENDPOINT);
    return response.data;
  } catch (error) {
    console.error('API request failed:', error.message);
    throw error;
  }
};

const runApiRequestJob = async () => {
  console.log('Running API request job...');
  try {
    const responseData = await makeApiRequest();
    return responseData;
  } catch (error) {
    return null;
  }
};

// Schedule the API request job to run every 15 minutes
cron.schedule('*/15 * * * *', async () => {
  const responseData = await runApiRequestJob();
  if (responseData) {
    // Process the response data here
    console.log('API request successful:', responseData);
  } else {
    console.log('API request failed');
  }
});
