require("dotenv").config();
const pool = require("../config/db");
const jwt = require("jsonwebtoken");

const generateStudentToken = async (studentId) => {
  try {
    const timestamp = new Date();
    const token = jwt.sign({ id: studentId }, process.env.TOKEN_SECRET);
    const query = `INSERT INTO student_token (token, fk_student, created_at) VALUES ($1, $2, $3)`;
    const queryParams = [token, studentId, timestamp];

    await pool.query(query, queryParams);

    return token;
  } catch (err) {
    throw new Error(err);
  }
};

module.exports = generateStudentToken;