require("dotenv").config();
const pool = require("../config/db");
const jwt = require("jsonwebtoken");

const generateTeacherToken = async (teacherId) => {
  try {
    const timestamp = new Date();
    const token = jwt.sign({ id: teacherId }, process.env.TOKEN_SECRET);
    const query = `INSERT INTO teacher_token (token, fk_teacher, created_at) VALUES ($1, $2, $3)`;
    const queryParams = [token, teacherId, timestamp];

    await pool.query(query, queryParams);

    return token;
  } catch (err) {
    throw new Error(err);
  }
};

module.exports = generateTeacherToken;